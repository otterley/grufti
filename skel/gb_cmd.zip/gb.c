/******************************************************************************
 * Steve Rider - stever@area23.org
 * Grufti - an interactive, service-oriented bot for IRC
 *
 * gb.c - Telnet interface for Grufti1.0
 *****************************************************************************/

/*
 *  Instructions:
 *    1) Edit the lines below to YOUR username and YOUR password on the bot
 *    2) Compile with: gcc -o gb gb.c
 *
 *    For example, if your username was Steve and your password was coolio,
 *    the lines below would read:
 *      char u[] = "Steve";
 *      char p[] = "coolio";
 */
char u[] = "yourusername";
char p[] = "yourpassword";


/*
 *  The following settings define the hostname and port of the bot you are
 *  trying to access.  Hopefully, these values were set by the bot master
 *  and you shouldn't have to change anything.  If you know they are wrong,
 *  ask your bot master for the information.
 */
char host[] = "216.160.116.185";		/* area23.org */
int port = 8888;


/******************************************************************************
 *
 * NO NEED TO EDIT ANYTHING BELOW THIS POINT
 *
 *****************************************************************************/



/* gb.c */
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <varargs.h>

#define LOGFILE "/tmp/log"
int sock;
int version = 1002;
int got_anything = 0;
char con_flags = 0;
int mult_args = 0;
#define SENTCMD		0x01

char cmd[BUFSIZ];
char elem[BUFSIZ];
void gotactivity(int sock, char *buf, int len);
void gotEOF();
void gotsocketerror(int sock);
void disconnect(int sock);
void do_grufti_down();
struct my_queue *send_on_match(char *waitstr, char *sendstr, int wait_time, int *x);

/* stever.c */
#include <string.h>
#define NOTELENGTH 400

struct my_queue {
	char *item;
	struct my_queue *next;
};

struct my_queue *add_q(char *s, struct my_queue *q);
void putlog();
void splitc(char *first, char *rest, char divider);
void time_token(char *timebuf, long time, int type);
void date_token(char *timebuf, long time, int type);
void make_date(char *date, time_t time);
struct my_queue *split_string(char *s);
void rmspace(char *s);

/* net.c */
#include <limits.h>
#include <netdb.h>
#if HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>      /* is this really necessary? */
#include <errno.h>
#include <fcntl.h>
#define PROXY_SUN 2
#define PROXY_SOCKS 1
#define MAXSOCKS 60
#define SOCK_UNUSED     0x01    /* empty socket */
#define SOCK_BINARY	0x02	/* do not buffer input */
#define SOCK_LISTEN	0x04	/* listening port */
#define SOCK_CONNECT    0x08    /* connection attempt */
#define SOCK_NONSOCK	0x10	/* used for file i/o on debug */
#define SOCK_STRONGCONN	0x20	/* don't report success until sure */
#define STDIN 0
#define STDOUT 1
#define STDERR 2
typedef unsigned int IP;

int open_telnet_raw(int sock, char *server, int sport);
int open_telnet(char *server, int port);
int getsock(int options);
void setsock(int sock, int options);
void killsock(int sock);
IP getmyip();
void my_memcpy(char *dest, char *src, int len);
void my_bzero(char *dest, int len);
int proxy_connect(int sock, char *host, int port, int proxy);
void init_net();
void getmyhostname(char *s);
void neterror(char *s);
char *hostnamefromip(unsigned long ip);
int sockread(char *s, int *len);
int sockgets(char *s, int *len);
void tputs(int z, char *s);
void dequeue_sockets();
void tprintf();

void main(int argc, char **argv)
{
	int	i, xx, start = 1;
	time_t	then, now;
	char	buf[BUFSIZ];

	if(argc < 2)
	{
		printf("Usage: gb [-m] <command [,command]>\n");
		printf("    Use the -m switch to specify multiple arguments.\n");
		printf("    Example: 'gb -m who #gothic, rn new, seen Arkham'\n");
		exit(0);
	}

	strcpy(cmd,"");

	if(strcasecmp(argv[1],"-m") == 0)
	{
		start++;
		mult_args = 1;
	}

	for(i=start;i<argc;i++)
		sprintf(cmd,"%s%s ",cmd,argv[i]);

	/* Open connection */
	init_net();
	sock = open_telnet(host,port);
	if(sock < 0)
		do_grufti_down();

	/* Connection established.  Sent program id, version, user and pass */
	tprintf(sock,"grufti-interface %d %s %s\n",version,u,p);

	/* now wait for activity */
	now = time(NULL);
	while(1)
	{
		/* watch for activity */

		then = now;
		now = time(NULL);

		if(now != then)
			;

		/* Check network */
		dequeue_sockets();
		xx = sockgets(buf,&i);

		if(xx == -1)
			gotEOF();
		else if (xx >= 0)
			gotactivity(xx,buf,i);
		else if((xx == -2) && (errno != EINTR))
			gotsocketerror(xx);
	}
}

void gotEOF()
{
	if(!got_anything)
		do_grufti_down();

	exit(0);
}

void disconnect(int sock)
{
	killsock(sock);
}

void gotsocketerror(int sock)
{
	/* Socket error */
	disconnect(sock);
	exit(0);
}

void gotactivity(int sock, char *buf, int i)
{
	if(!got_anything && buf[0] == 0)
	{
		got_anything = 1;
		return;
	}

	if(strncmp(buf,"OKOK>",5) == 0)
	{
		/* Multiple args, send each one */
		if(mult_args)
		{
			if(con_flags & SENTCMD)
			{
				/* are we done yet? */
				if(cmd[0])
				{
					if(strchr(cmd,','))
						splitc(elem,cmd,',');
					else
					{
						strcpy(elem,cmd);
						cmd[0] = 0;
					}
				}
				else
				{
					disconnect(sock);
					exit(0);
				}
			}
			else
			{
				if(strchr(cmd,','))
					splitc(elem,cmd,',');
				else
				{
					strcpy(elem,cmd);
					cmd[0] = 0;
				}
			}
		}

		/* Single args */
		else
		{
			/* We've already sent command.  so we're done. */
			if(con_flags & SENTCMD)
			{
				disconnect(sock);
				exit(0);
			}
			else
				strcpy(elem,cmd);
		}
			

		/* Got OK and haven't sent command.  send it */
		tprintf(sock,"%s\n",elem);
		con_flags |= SENTCMD;
	}
	else
		printf("%s\n",buf);
}

void do_grufti_down()
{
	printf("Sorry, unable to login at this time.  Grufti may be down.\n");
	exit(0);
}


struct my_queue *send_on_match(char *waitstr, char *sendstr, int wait_time, int *x)
{
	int gotit=0,len;
	char s[512],s1[513];
	int timing_s;
	struct timeval start_t,finish_t;
	struct timezone tz;
	struct my_queue *q=NULL;

        gettimeofday(&start_t,&tz);

	while(!gotit)
	{
		dequeue_sockets();
		*x=sockgets(s,&len);
		if(*x>=0)
		{
			/* No error */
			printf("%s\n",s);
			if(strstr(s,waitstr))
			{
				gotit=1;
				tprintf(sock,"%s\n",sendstr);
				printf("--> %s\n",sendstr);
				break;
			}
			else
			{
				sprintf(s1,"%s\n",s);
				q=add_q(s1,q);
				printf("Queing: \"%s\"\n",s);
			}
		}
		else if(*x==-3)	/* No input ready. */
		{
        		gettimeofday(&finish_t,&tz);
		        timing_s=finish_t.tv_sec - start_t.tv_sec;
			if(timing_s>wait_time)
			{
				*x=0;
				return NULL;
			}
		}
		else if(*x==-1)
			return NULL;
	}
	*x=1;
	return q;
}

/**************************************************************************** 
  stever.c - toolbox of miscellaneous routines used with gb.c.
 ****************************************************************************/

static char *months[] =
{
        "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"
};
 
static char *week_days[] =
{
        "Sun","Mon","Tue","Wed","Thu","Fri","Sat"
};

void putlog(va_alist)
va_dcl
{
	va_list va;
	char *format,s[1024],s1[40],s2[1024];
	FILE *f;
	time_t tt;

	va_start(va);
	format=va_arg(va,char *);
	vsprintf(s,format,va);

	if(s[0]==0)
		strcpy(s,"\n");
	tt=time(NULL);
	strcpy(s1,ctime(&tt));
	strcpy(s1,&s1[11]);
	s1[5]=0;
	sprintf(s2,"[%s] %s\n",s1,s);
	strcpy(s,s2);

	f=fopen(LOGFILE,"a+");
	if(f!=NULL)
	{
		fprintf(f,"%s",s);
		fclose(f);
	}

	va_end(va);
}

struct my_queue *add_q(char *s, struct my_queue *q)
{
	struct my_queue *x;
	struct my_queue *tmp;

	x=(struct my_queue *)malloc(sizeof(struct my_queue));
	x->next=NULL;
	x->item=(char *)malloc(strlen(s)+1);
	strcpy(x->item,s);

	tmp=q;
	if(tmp==NULL)
	{
		tmp=x;
		return tmp;
	}
	while(tmp->next!=NULL)
		tmp=tmp->next;

	tmp->next=x;
	return q;
}

void splitc(char *first, char *rest, char divider)
{
	char *p;

	p=strchr(rest,divider);
	if(p==NULL)
	{
		if((first!=rest)&&(first!=NULL))
			first[0]=0;
		return;
	}
	*p=0;
	if(first!=NULL)
		strcpy(first,rest);
	if(first!=rest)
		strcpy(rest,p+1);
}

void make_date(char *date, time_t time)
{ 
	struct tm *btime;

	btime=localtime(&time);
	sprintf(date,"%s, %s %d%s (%-2.2d:%-2.2d)",week_days[btime->tm_wday],months[btime->tm_mon],btime->tm_mday,btime->tm_mday<10?" ":"",btime->tm_hour,btime->tm_min);
	return;
}   
    
void date_token(char *timebuf, time_t time, int type)
{  
	struct tm *btime;
    
	btime=localtime(&time);
	strcpy(timebuf,"");
	switch(type)
	{
		case (1) : sprintf(timebuf,"%s",months[btime->tm_mon]); break;
		case (2) : sprintf(timebuf,"%-2.2d",btime->tm_mday); break;
		case (3) : sprintf(timebuf,"%-2.2d",btime->tm_year); break;
		case (4) : sprintf(timebuf,"%d",btime->tm_mday); break;
		case (5) : sprintf(timebuf,"%-2.2d",btime->tm_year + 1900);break ;   
		case (6) : sprintf(timebuf,"%-2.2d",(btime->tm_mon+1)); break;
		case (7) : sprintf(timebuf,"%s",week_days[btime->tm_wday]); break;
		default : return; break;
	}
}

void time_token(char *timebuf, time_t time, int type)
{
	struct tm *btime;

	btime=localtime(&time);
	strcpy(timebuf,"");
	switch(type)
	{
		case (1): sprintf(timebuf,"%d",btime->tm_hour); break;
		case (2): sprintf(timebuf,"%d",btime->tm_min); break;
		case (3): sprintf(timebuf,"%d",btime->tm_sec); break;
		case (4): sprintf(timebuf,"%-2.2d",btime->tm_hour); break;
		case (5): sprintf(timebuf,"%-2.2d",btime->tm_min); break;
		case (6): sprintf(timebuf,"%-2.2d",btime->tm_sec); break;
		default: return ; break;
	}
}

struct my_queue *split_string(char *s)
{
	struct my_queue *q=NULL;
	char d1[4096], d2[4096];
	char buf[4096];
	int i,first_space=0,len;

	strcpy(d1,"");
	strcpy(d2,"");
	rmspace(s);
	len=strlen(s);
	for(i=0;i<len;i++)
	{
		if(s[i]==32 || i==(len-1))
		{
			if(!first_space)
			{
				first_space=1;
				if((strlen(d1)+strlen(d2)) <= NOTELENGTH)
				{
					strcat(d2,d1);
					strcpy(d1,"");
				}
				else
				{
					q=add_q(d2,q);
					strcpy(d2,d1);
					rmspace(d2);
					strcpy(d1,"");
					first_space=0;
				}
			}
		}
		else
			first_space=0;
		sprintf(d1,"%s%c",d1,s[i]);
	}
	sprintf(buf,"%s%s",d2,d1);
	q=add_q(buf,q);
	return q;
}

void rmspace(char *s) 
{               
#define whitespace(c) ( ((c)==32) || ((c)==9) || ((c)==13) || ((c)==10) )
	char *p;
	/* wipe end of string */
	for (p=s+strlen(s)-1; ((whitespace(*p))&&(p>=s)); p--);
	if (p!=s+strlen(s)-1)
		*(p+1)=0;
	for (p=s; ((whitespace(*p)) && (*p)); p++);
	if (p!=s)
		strcpy(s,p);
}     


/**************************************************************************** 
  net.c - socket routines, handles all network i/o.  Ability to buffer input
          and output.  handles binary data as well.
 ****************************************************************************/

char username[32]="";
char hostname[121]="";
char myip[121]="";
char firewall[121]="";
int firewallport=178;
typedef struct {
	int sock;
	char flags;
	char *inbuf;
	char *outbuf;
} sock_list;

sock_list socklist[MAXSOCKS];

/* starts a connection attempt to a socket */
/* returns <0 if connection refused: */
/*   -1  neterror() type error */
/*   -2  can't resolve hostname */
int open_telnet_raw(int sock,char *server,int sport)
{
	struct sockaddr_in name;
	struct hostent *hp;
	int i,port,proxy=0;
	char host[121];

	/* firewall?  use socks */
	if (firewall[0])
	{
		if (firewall[0]=='!')
		{
			proxy=PROXY_SUN;
			strcpy(host,&firewall[1]);
		}
		else
		{
			proxy=PROXY_SOCKS;
			strcpy(host,firewall);
		}
		port=firewallport;
	}
	else
	{
		strcpy(host,server);
		port=sport;
	}

	/* multi-hosted machines: */
	my_bzero((char *)&name,sizeof(struct sockaddr_in));
	name.sin_family=AF_INET;
	name.sin_addr.s_addr=(*myip ? getmyip() : INADDR_ANY);
	if (bind(sock,(struct sockaddr *)&name,sizeof(name))<0)
	{
		killsock(sock);
		return -1;
	}
	my_bzero((char *)&name,sizeof(struct sockaddr_in));
	name.sin_family=AF_INET;
	name.sin_port=htons(port);
	/* numeric IP? */
	if ((host[strlen(host)-1] >= '0') && (host[strlen(host)-1] <= '9'))
		name.sin_addr.s_addr=inet_addr(host);
	else
	{
		/* no, must be host.domain */
		alarm(10);
		hp=gethostbyname(host);
		alarm(0);
		if (hp==NULL)
		{
			killsock(sock);
			return -2;
		}
		my_memcpy((char *)&name.sin_addr,hp->h_addr,hp->h_length);
		name.sin_family=hp->h_addrtype;
	}
	for (i=0; i<MAXSOCKS; i++)
	{
		if (!(socklist[i].flags & SOCK_UNUSED) && (socklist[i].sock==sock))
		{
			socklist[i].flags |= SOCK_CONNECT;
		}
	}
	if (connect(sock,(struct sockaddr *)&name,sizeof(struct sockaddr_in)) <0)
	{
		if (errno==EINPROGRESS)
		{
			/* firewall?  announce connect attempt to proxy */
			if (firewall[0])
				return proxy_connect(sock,server,sport,proxy);
			return sock;   /* async success! */
		}
		else
		{
			killsock(sock);
			return -1;
		}
	}
	/* synchronous? :/ */
	if (firewall[0])
		return proxy_connect(sock,server,sport,proxy);
	return sock;
}


int open_telnet(char *server,int port)
{
	return open_telnet_raw(getsock(0),server,port);
}


int getsock(int options)
{
	int sock=socket(AF_INET,SOCK_STREAM,0);
	if(sock<0)
		exit(0);
	setsock(sock,options);
	return sock;
}

/* request a normal socket for i/o */
void setsock(int sock,int options)
{
	int i;
	int parm;
	for (i=0; i<MAXSOCKS; i++)
	{
		if (socklist[i].flags & SOCK_UNUSED)
		{
			/* yay!  there is table space */
			socklist[i].inbuf=socklist[i].outbuf=NULL;
			socklist[i].flags=options;
			socklist[i].sock=sock;
			if ((sock!=STDOUT) && !(socklist[i].flags & SOCK_NONSOCK))
			{
				parm=1;
				setsockopt(sock,SOL_SOCKET,SO_KEEPALIVE,(void *)&parm,sizeof(int));
				parm=0;
				setsockopt(sock,SOL_SOCKET,SO_LINGER,(void *)&parm,sizeof(int));
			}
			if (options & SOCK_LISTEN)
			{
				/* lets us grab the same port again next time */
				parm=1;
				setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,(void *)&parm,sizeof(int));
			}
			/* yay async i/o ! */
			fcntl(sock,F_SETFL,O_NONBLOCK);
			return;
		}
	}
	exit(0);
}


/* done with a socket */
void killsock(int sock)
{
	int i;
	for (i=0; i<MAXSOCKS; i++)
	{
		if (socklist[i].sock==sock)
		{
			close(socklist[i].sock);
			if (socklist[i].inbuf != NULL)
				free(socklist[i].inbuf);
			if (socklist[i].outbuf != NULL)
				free(socklist[i].outbuf);
			socklist[i].flags=SOCK_UNUSED;
			return;
		}
	}
}


/* get my ip number */
IP getmyip()
{
	struct hostent *hp;
	char s[121];
	IP ip;
	struct in_addr *in;

	/* could be pre-defined */
	if (myip[0])
	{
		if ((myip[strlen(myip)-1] >= '0') && (myip[strlen(myip)-1] <= '9'))
			return (IP)inet_addr(myip);
	}

	/* also could be pre-defined */
	if (hostname[0])
		hp=gethostbyname(hostname);
	else
	{
		gethostname(s,120);
		hp=gethostbyname(s);
	}
	if (hp==NULL)
		exit(0);
	in=(struct in_addr *)(hp->h_addr_list[0]);
	ip=(IP)(in->s_addr);
	return ip;
}


/* *sigh* */
void my_memcpy(char *dest,char *src,int len)
{
	while (len--)
		*dest++=*src++;
}


/* bzero() is bsd-only, so here's one for non-bsd systems */
void my_bzero(char *dest,int len)
{
	while (len--)
		*dest++=0;
}


/* send connection request to proxy */
int proxy_connect(int sock,char *host,int port,int proxy)
{
	unsigned char x[10];
	struct hostent *hp;
	char s[30];

	/* socks proxy */
	if (proxy==PROXY_SOCKS)
	{
		/* numeric IP? */
		if ((host[strlen(host)-1] >= '0') && (host[strlen(host)-1] <= '9'))
		{
			IP ip=(IP)inet_addr(host);
			x[0]=(ip>>24);
			x[1]=(ip>>16)&0xff;
			x[2]=(ip>>8)&0xff;
			x[3]=ip&0xff;
		}
		else
		{
			/* no, must be host.domain */
			alarm(10);
			hp=gethostbyname(host);
			alarm(0);
			if (hp==NULL)
			{
				killsock(sock);
				return -2;
			}
			my_memcpy(x,(char *)hp->h_addr,hp->h_length);
		}
		sprintf(s,"\004\001%c%c%c%c%c%c%s",(port>>8)%256,(port%256),x[0],x[1],x[2], x[3],username);
		write(sock,s,strlen(s)+1);
	}
	else if (proxy==PROXY_SUN)
	{
		sprintf(s,"%s %d\n",host,port);
		write(sock,s,strlen(s));
	}
	return sock;
}


/* Init sock table */
void init_net()
{
	int i;
	for(i=0;i<MAXSOCKS;i++)
		socklist[i].flags=SOCK_UNUSED;
}


/* puts full hostname in s */
void getmyhostname(char *s)
{
	struct hostent *hp;
	char *p;
	if (hostname[0])
	{
		strcpy(s,hostname);
		return;
	}
	p=getenv("HOSTNAME");
	if (p!=NULL)
	{
		strcpy(s,p);
		if (strchr(s,'.')!=NULL)
			return;
	}
	gethostname(s,80);
	if (strchr(s,'.')!=NULL)
		return;
	hp=gethostbyname(s);
	if (hp==NULL)
	{
		printf("Hostname self-lookup failed.\n");
		exit(0);
	}
	strcpy(s,hp->h_name);
	if (strchr(s,'.')!=NULL)
		return;
	if (hp->h_aliases[0] == NULL)
	{
		printf("Can't determine your hostname!\n");
		exit(0);
	}
	strcpy(s,hp->h_aliases[0]);
	if (strchr(s,'.')==NULL)
	{
		printf("Can't determine your hostname!\n");
		exit(0);
	}
}


void neterror(char *s)
{
	switch(errno)
	{
	case EADDRINUSE: strcpy(s,"Address already in use"); break;
	case EADDRNOTAVAIL: strcpy(s,"Address invalid on remote machine"); break;
	case EAFNOSUPPORT: strcpy(s,"Address family not supported"); break;
	case EALREADY: strcpy(s,"Socket already in use"); break;
	case EBADF: strcpy(s,"Socket descriptor is bad"); break;
	case ECONNREFUSED: strcpy(s,"Connection refused"); break;
	case EFAULT: strcpy(s,"Namespace segment violation"); break;
	case EINPROGRESS: strcpy(s,"Operation in progress"); break;
	case EINTR: strcpy(s,"Timeout"); break;
	case EINVAL: strcpy(s,"Invalid namespace"); break;
	case EISCONN: strcpy(s,"Socket already connected"); break;
	case ENETUNREACH: strcpy(s,"Network unreachable"); break;
	case ENOTSOCK: strcpy(s,"File descriptor, not a socket"); break;
	case ETIMEDOUT: strcpy(s,"Connection timed out"); break;
	case ENOTCONN: strcpy(s,"Socket is not connected"); break;
	case EHOSTUNREACH: strcpy(s,"Host is unreachable"); break;
	case EPIPE: strcpy(s,"Broken pipe"); break;
#ifdef ECONNRESET
	case ECONNRESET: strcpy(s,"Connection reset by peer"); break;
#endif
#ifdef EACCES
	case EACCES: strcpy(s,"Permission denied"); break;
#endif
	case 0: strcpy(s,"Error 0"); break;
	default: sprintf(s,"Unforseen error %d",errno); break;
	}
}  


/* given network-style IP address, return hostname */
/* hostname will be "##.##.##.##" format if there was an error */
char *hostnamefromip(unsigned long ip)
{
	struct hostent *hp;
	unsigned long addr=ip;
	unsigned char *p;
	static char s[121];
	alarm(10);
	hp=gethostbyaddr((char *)&addr,sizeof(addr),AF_INET);
	alarm(0);
	if (hp==NULL)
	{
		p=(unsigned char *)&addr;
		sprintf(s,"%u.%u.%u.%u",p[0],p[1],p[2],p[3]);
		return s;
	}
	strcpy(s,hp->h_name);
	return s;
}


/* attempts to read from all the sockets in socklist */
/* fills s with up to 511 bytes if available, and returns the array index */
/* on EOF, returns -1, with socket in len */
/* on socket error, returns -2 */
/* if nothing is ready, returns -3 */
int sockread(char *s, int *len)
{
	fd_set fd;
	int fds,i,x;
	struct timeval t;
	int grab=511;
	fds=getdtablesize();
#ifdef FD_SETSIZE
	if (fds>FD_SETSIZE) fds=FD_SETSIZE; /* fixes YET ANOTHER freebsd bug!!! */
#endif
	/* timeout: 1 sec */
	t.tv_sec=1;
	t.tv_usec=0;
	FD_ZERO(&fd);
	for (i=0; i<MAXSOCKS; i++)
		if (!(socklist[i].flags & SOCK_UNUSED))
		{
			if ((socklist[i].sock==STDOUT))
				FD_SET(STDIN,&fd);
			else
				FD_SET(socklist[i].sock,&fd);
		}
#ifdef HPUX
	x=select(fds,(int *)&fd,(int *)NULL,(int *)NULL,&t);
#else
	x=select(fds,&fd,NULL,NULL,&t); 
#endif
	if (x>0)
	{
		/* something happened */
		for (i=0; i<MAXSOCKS; i++)
		{
			if ((!(socklist[i].flags & SOCK_UNUSED)) && ((FD_ISSET(socklist[i].sock,&fd)) || ((socklist[i].sock==STDOUT) && (FD_ISSET(STDIN,&fd)))))
			{
				if (socklist[i].flags & (SOCK_LISTEN|SOCK_CONNECT))
				{
					/* listening socket -- don't read, just return activity */
					/* same for connection attempt */
					if (!(socklist[i].flags & SOCK_STRONGCONN))
					{
						s[0]=0;
						*len=0;
						return i;
					}
					/* (for strong connections, require a read to succeed first) */
					if ((firewall[0]) && (firewall[0]!='!') && (socklist[i].flags&SOCK_CONNECT))
					{
						/* hang around to get the return code from proxy */
						grab=8;
					}
				}
				if ((socklist[i].sock==STDOUT))
					x=read(STDIN,s,grab);
				else
					x=read(socklist[i].sock,s,grab);
				if (x<=0)
				{
					/* eof */
					*len=socklist[i].sock;
					socklist[i].flags &= ~SOCK_CONNECT;
					return -1;
				}
				s[x]=0;
				*len=x;
				if ((firewall[0]) && (socklist[i].flags & SOCK_CONNECT))
				{
					switch(s[1])
					{
					case 90:   /* success */
						s[0]=0; *len=0; return i;
					case 91:   /* failed */
						errno=ECONNREFUSED; break;
					case 92:   /* no identd */
					case 93:   /* identd said wrong username */
						errno=ENETUNREACH; break;
						/* a better error message would be "socks misconfigured" */
						/* or "identd not working" but this is simplest */
					}
					*len=socklist[i].sock;
					socklist[i].flags &= ~SOCK_CONNECT;
					return -1;
				}
				return i;
			}
		}
	}
	else if (x==-1)
		return -2;   /* socket error */
	else
	{
		s[0]=0;
		*len = 0;
	}
	return -3;
}


/* sockgets: buffer and read from sockets

 attempts to read from all registered sockets for up to one second.  if
     after one second, no complete data has been received from any of the
     sockets, 's' will be empty, 'len' will be 0, and sockgets will return
     -3.
 if there is returnable data received from a socket, the data will be
     in 's' (null-terminated if non-binary), the length will be returned
     in len, and the socket number will be returned.
 normal sockets have their input buffered, and each call to sockgets
     will return one line terminated with a '\n'.  binary sockets are not
     buffered and return whatever coems in as soon as it arrives.
 listening sockets will return an empty string when a connection comes in.
     connecting sockets will return an empty string on a successful connect,
     or EOF on a failed connect.
 if an EOF is detected from any of the sockets, that socket number will be
     put in len, and -1 will be returned.

 (the maximum length of the string returned is 512 (including null))
*/
int sockgets(char *s,int *len)
{
	char xx[514],*p,*px;
	int ret,i;

	/* check for stored-up data waiting to be processed */
	for (i=0; i<MAXSOCKS; i++)
	{
		if (!(socklist[i].flags & SOCK_UNUSED) && (socklist[i].inbuf != NULL))
		{
			/* look for \r too cos windows can't follow RFCs */
			p=strchr(socklist[i].inbuf,'\n');
			if (p==NULL)
				p=strchr(socklist[i].inbuf,'\r');
			if (p!=NULL)
			{
				*p=0;
				if (strlen(socklist[i].inbuf) > 510)
					socklist[i].inbuf[510]=0;
				strcpy(s,socklist[i].inbuf);
				px=(char *)malloc(strlen(p+1)+1);
				strcpy(px,p+1);
				free(socklist[i].inbuf);
				if (px[0])
					socklist[i].inbuf=px;
				else
				{
					free(px);
					socklist[i].inbuf=NULL;
				}
				/* strip CR if this was CR/LF combo */
				if (s[strlen(s)-1]=='\r')
					s[strlen(s)-1]=0;
				*len = strlen(s);
				return socklist[i].sock;
			}
		}
	}

	/* no pent-up data of any worth -- down to business */
	*len=0;
	ret=sockread(xx,len);
	if (ret<0)
	{
		s[0]=0;
		return ret;
	}

	/* binary and listening sockets don't get buffered */
	if (socklist[ret].flags & SOCK_CONNECT)
	{
		if (socklist[ret].flags & SOCK_STRONGCONN)
		{
			socklist[ret].flags &= ~SOCK_STRONGCONN;
			/* buffer any data that came in, for future read */
			socklist[ret].inbuf=(char *)malloc(strlen(xx)+1);
			strcpy(socklist[ret].inbuf,xx);
		}
		socklist[ret].flags &= ~SOCK_CONNECT;
		s[0]=0;
		return socklist[ret].sock;
	}
	if (socklist[ret].flags & SOCK_BINARY)
	{
		my_memcpy(s,xx,*len);
		return socklist[ret].sock;
	}
	if (socklist[ret].flags & SOCK_LISTEN)
		return socklist[ret].sock;

	/* might be necessary to prepend stored-up data! */
	if (socklist[ret].inbuf != NULL)
	{
		p=socklist[ret].inbuf;
		socklist[ret].inbuf=(char *)malloc(strlen(p)+strlen(xx)+1);
		strcpy(socklist[ret].inbuf,p);
		strcat(socklist[ret].inbuf,xx);
		free(p);
		if (strlen(socklist[ret].inbuf) < 512)
		{
			strcpy(xx,socklist[ret].inbuf);
			free(socklist[ret].inbuf);
			socklist[ret].inbuf=NULL;
		}
		else
		{
			p=socklist[ret].inbuf;
			socklist[ret].inbuf=(char *)malloc(strlen(p)-509);
			strcpy(socklist[ret].inbuf,p+510); *(p+510)=0;
			strcpy(xx,p);
			free(p);
			/* (leave the rest to be post-pended later) */
		}
	}

	/* look for EOL marker; if it's there, i have something to show */
	p=strchr(xx,'\n');
	if (p==NULL)
		p=strchr(xx,'\r');
	if (p!=NULL)
	{
		*p=0;
		strcpy(s,xx);
		strcpy(xx,p+1);
		if (s[strlen(s)-1]=='\r')
			s[strlen(s)-1]=0;
/* NO!		if (!s[0]) strcpy(s," ");  */
	}
	else
	{
		s[0]=0;
		if (strlen(xx)>=510)
		{
			/* string is too long, so just insert fake \n */
			strcpy(s,xx);
			xx[0]=0;
		}
	}

	*len = strlen(s);
	/* anything left that needs to be saved? */
	if (!xx[0])
	{
		if (s[0])
			return socklist[ret].sock;
		else
			return -3;
	}

	/* prepend old data back */
	if (socklist[ret].inbuf != NULL)
	{
		p=socklist[ret].inbuf;
		socklist[ret].inbuf=(char *)malloc(strlen(p)+strlen(xx)+1);
		strcpy(socklist[ret].inbuf,xx);
		strcat(socklist[ret].inbuf,p);
		free(p);
	}
	else
	{
		socklist[ret].inbuf=(char *)malloc(strlen(xx)+1);
		strcpy(socklist[ret].inbuf,xx);
	}
	if (s[0])
		return socklist[ret].sock;
	else
		return -3;
}


/* dump something to a socket */
void tputs(int z, char *s)
{
	int i,x;
	char *p;
	if (z<0)
		return;   /* um... HELLO?!  sanity check please! */
	if (((z==STDOUT) || (z==STDERR)))
	{
		write(z,s,strlen(s));
		return;
	}
	for (i=0; i<MAXSOCKS; i++)
	{
		if (!(socklist[i].flags & SOCK_UNUSED) && (socklist[i].sock==z))
		{
			if (socklist[i].outbuf != NULL)
			{
				/* already queueing: just add it */
				p=(char *)malloc(strlen(socklist[i].outbuf)+strlen(s)+1);
				strcpy(p,socklist[i].outbuf);
				strcat(p,s);
				free(socklist[i].outbuf);
				socklist[i].outbuf=p;
				return;
			}
			x=write(z,s,strlen(s));
			if (x==(-1))
				x=0;
			if (x < strlen(s))
			{
				/* socket is full, queue it */
				socklist[i].outbuf=(char *)malloc(strlen(s)-x+1);
				strcpy(socklist[i].outbuf,&s[x]);
			}
			return;
		}
	}
	printf("    '%s'\n",s);
}


/* tputs might queue data for sockets, let's dump as much of it as */
/* possible */
void dequeue_sockets()
{
	int i;
	char *p;
	for (i=0; i<MAXSOCKS; i++)
	{
		if (!(socklist[i].flags & SOCK_UNUSED) && (socklist[i].outbuf != NULL))
		{
			/* trick tputs into doing the work */
			p=socklist[i].outbuf;
			socklist[i].outbuf=NULL;
			tputs(socklist[i].sock,p);
			free(p);
		}
	}
}


/* like fprintf, but instead of preceding the format string with a FILE
   pointer, precede with a socket number */
void tprintf(va_alist)
va_dcl
{
	char *format;
	int sock;
	va_list va;
	static char SBUF2[768];
	va_start(va);
	sock=va_arg(va,int);
	format=va_arg(va,char *);
	vsprintf(SBUF2,format,va);
	if (strlen(SBUF2)>510)
		SBUF2[510]=0;   /* server can only take so much */
	tputs(sock,SBUF2);
	va_end(va);
}
